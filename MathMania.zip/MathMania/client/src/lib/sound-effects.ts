// Simple sound effect system using Web Audio API
class SoundEffect {
  private audioContext: AudioContext | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch (e) {
        console.warn('Web Audio API not supported');
      }
    }
  }

  private async playTone(frequency: number, duration: number, type: OscillatorType = 'sine') {
    if (!this.audioContext) return;

    // Resume context if suspended (required by some browsers)
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
    oscillator.type = type;

    gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  async playCorrectSound() {
    // Play a cheerful ascending sound
    await this.playTone(523, 0.2); // C5
    setTimeout(() => this.playTone(659, 0.2), 100); // E5
    setTimeout(() => this.playTone(784, 0.3), 200); // G5
  }

  async playIncorrectSound() {
    // Play a gentle descending sound
    await this.playTone(400, 0.3); // G4
    return new Promise<void>((resolve) => {
      setTimeout(async () => {
        await this.playTone(350, 0.4); // F4
        resolve();
      }, 150);
    });
  }

  async playCelebrationSound() {
    // Play a victory fanfare
    const notes = [523, 659, 784, 1047]; // C5, E5, G5, C6
    const promises = notes.map((note, i) => {
      return new Promise<void>((resolve) => {
        setTimeout(async () => {
          await this.playTone(note, 0.3);
          resolve();
        }, i * 100);
      });
    });
    
    await Promise.all(promises);
  }

  async playClickSound() {
    // Play a subtle click sound
    await this.playTone(800, 0.1, 'square');
  }
}

const soundEffect = new SoundEffect();

export async function playSound(type: 'correct' | 'incorrect' | 'celebration' | 'click') {
  try {
    switch (type) {
      case 'correct':
        await soundEffect.playCorrectSound();
        break;
      case 'incorrect':
        await soundEffect.playIncorrectSound();
        break;
      case 'celebration':
        await soundEffect.playCelebrationSound();
        break;
      case 'click':
        await soundEffect.playClickSound();
        break;
    }
  } catch (error) {
    console.warn('Could not play sound:', error);
  }
}
