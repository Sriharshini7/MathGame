export interface Question {
  id: number;
  operation: string;
  num1: number;
  num2: number;
  correctAnswer: number;
  options: number[];
  emoji: string;
}

const emojis = ['🤔', '🧮', '💭', '🎯', '🔍', '💡', '⭐', '🎲', '🎪', '🎨'];

function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function generateOptions(correctAnswer: number, operation: string): number[] {
  const options = new Set([correctAnswer]);
  
  // Generate wrong options based on operation
  while (options.size < 4) {
    let wrongAnswer: number;
    
    switch (operation) {
      case 'addition':
        wrongAnswer = correctAnswer + getRandomInt(-5, 5);
        break;
      case 'subtraction':
        wrongAnswer = correctAnswer + getRandomInt(-3, 8);
        break;
      case 'multiplication':
        wrongAnswer = correctAnswer + getRandomInt(-10, 15);
        break;
      case 'division':
        wrongAnswer = correctAnswer + getRandomInt(-2, 5);
        break;
      default:
        wrongAnswer = correctAnswer + getRandomInt(-5, 5);
    }
    
    if (wrongAnswer > 0 && wrongAnswer !== correctAnswer) {
      options.add(wrongAnswer);
    }
  }
  
  return shuffleArray(Array.from(options));
}

function generateSingleQuestion(operation: string, id: number): Question {
  let num1: number, num2: number, correctAnswer: number;
  
  switch (operation) {
    case 'addition':
      num1 = getRandomInt(1, 20);
      num2 = getRandomInt(1, 20);
      correctAnswer = num1 + num2;
      break;
      
    case 'subtraction':
      num1 = getRandomInt(10, 30);
      num2 = getRandomInt(1, num1); // Ensure positive result
      correctAnswer = num1 - num2;
      break;
      
    case 'multiplication':
      num1 = getRandomInt(2, 12);
      num2 = getRandomInt(2, 12);
      correctAnswer = num1 * num2;
      break;
      
    case 'division':
      // Generate multiplication first, then reverse for clean division
      const product = getRandomInt(4, 100);
      num2 = getRandomInt(2, 10);
      num1 = product;
      // Adjust num1 to be divisible by num2
      num1 = Math.floor(num1 / num2) * num2;
      correctAnswer = num1 / num2;
      break;
      
    default:
      num1 = getRandomInt(1, 10);
      num2 = getRandomInt(1, 10);
      correctAnswer = num1 + num2;
  }
  
  const options = generateOptions(correctAnswer, operation);
  const emoji = emojis[Math.floor(Math.random() * emojis.length)];
  
  return {
    id,
    operation,
    num1,
    num2,
    correctAnswer,
    options,
    emoji
  };
}

export function generateQuestions(operation: string, count: number = 10): Question[] {
  const questions: Question[] = [];
  
  for (let i = 0; i < count; i++) {
    questions.push(generateSingleQuestion(operation, i + 1));
  }
  
  return questions;
}

export function calculateScore(correctAnswers: number, totalQuestions: number): number {
  return Math.round((correctAnswers / totalQuestions) * 100);
}
