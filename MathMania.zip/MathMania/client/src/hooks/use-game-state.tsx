import { useState, useCallback } from 'react';
import { generateQuestions, calculateScore, type Question } from '@/lib/game-logic';

export function useGameState() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [operation, setOperation] = useState<string>('');
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [isGameComplete, setIsGameComplete] = useState(false);

  const initializeGame = useCallback((selectedOperation: string) => {
    const newQuestions = generateQuestions(selectedOperation, 10);
    setQuestions(newQuestions);
    setCurrentQuestionIndex(0);
    setScore(0);
    setCorrectAnswers(0);
    setTotalQuestions(10);
    setOperation(selectedOperation);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setIsCorrect(false);
    setIsGameComplete(false);
  }, []);

  const selectAnswer = useCallback((answer: number) => {
    if (showFeedback || !questions.length) return;

    const currentQuestion = questions[currentQuestionIndex];
    const correct = answer === currentQuestion.correctAnswer;
    
    setSelectedAnswer(answer);
    setIsCorrect(correct);
    setShowFeedback(true);

    if (correct) {
      setCorrectAnswers(prev => prev + 1);
      setScore(prev => prev + 10);
    }
  }, [currentQuestionIndex, questions, showFeedback]);

  const nextQuestion = useCallback(() => {
    if (currentQuestionIndex + 1 >= questions.length) {
      // Save game results to sessionStorage before completing
      const gameResults = {
        score,
        operation,
        correctAnswers,
        totalQuestions
      };
      sessionStorage.setItem('mathGameResults', JSON.stringify(gameResults));
      setIsGameComplete(true);
      return;
    }

    setCurrentQuestionIndex(prev => prev + 1);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setIsCorrect(false);
  }, [currentQuestionIndex, questions.length, score, operation, correctAnswers, totalQuestions]);

  const resetGame = useCallback(() => {
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setScore(0);
    setCorrectAnswers(0);
    setTotalQuestions(0);
    setOperation('');
    setSelectedAnswer(null);
    setShowFeedback(false);
    setIsCorrect(false);
    setIsGameComplete(false);
  }, []);

  return {
    questions,
    currentQuestionIndex,
    score,
    correctAnswers,
    totalQuestions,
    operation,
    selectedAnswer,
    showFeedback,
    isCorrect,
    isGameComplete,
    initializeGame,
    selectAnswer,
    nextQuestion,
    resetGame
  };
}
