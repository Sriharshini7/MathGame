import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useUsername } from './use-username';

interface HighScores {
  addition: number;
  subtraction: number;
  multiplication: number;
  division: number;
}

const defaultHighScores: HighScores = {
  addition: 0,
  subtraction: 0,
  multiplication: 0,
  division: 0
};

export function useHighScores() {
  const { username, hasUsername } = useUsername();
  const queryClient = useQueryClient();
  const [localHighScores, setLocalHighScores] = useState<HighScores>(defaultHighScores);

  // Load local high scores from localStorage for anonymous users
  useEffect(() => {
    if (!hasUsername) {
      try {
        const saved = localStorage.getItem('mathGameHighScores');
        if (saved) {
          const parsed = JSON.parse(saved);
          setLocalHighScores({ ...defaultHighScores, ...parsed });
        }
      } catch (error) {
        console.warn('Failed to load high scores:', error);
      }
    }
  }, [hasUsername]);

  // Save local high scores to localStorage for anonymous users
  useEffect(() => {
    if (!hasUsername) {
      try {
        localStorage.setItem('mathGameHighScores', JSON.stringify(localHighScores));
      } catch (error) {
        console.warn('Failed to save high scores:', error);
      }
    }
  }, [localHighScores, hasUsername]);

  // Fetch database high scores for logged-in users
  const { data: databaseHighScores, error: leaderboardError } = useQuery({
    queryKey: ['/api/leaderboard'],
    enabled: hasUsername,
    retry: 2,
    staleTime: 30000, // 30 seconds
    select: (data: any[]) => {
      try {
        const scores: HighScores = { ...defaultHighScores };
        if (Array.isArray(data)) {
          data.forEach(leaderboard => {
            if (leaderboard && Array.isArray(leaderboard.scores) && leaderboard.scores.length > 0) {
              const userScore = leaderboard.scores.find((s: any) => s.username === username);
              if (userScore && typeof userScore.score === 'number') {
                scores[leaderboard.operation as keyof HighScores] = userScore.score;
              }
            }
          });
        }
        return scores;
      } catch (error) {
        console.warn('Error processing leaderboard data:', error);
        return defaultHighScores;
      }
    }
  });

  // Log any leaderboard errors for debugging
  useEffect(() => {
    if (leaderboardError) {
      console.warn('Leaderboard fetch error:', leaderboardError);
    }
  }, [leaderboardError]);

  // Mutation to save high scores to database
  const saveHighScoreMutation = useMutation({
    mutationFn: async (data: { username: string; operation: string; score: number }) => {
      return apiRequest('POST', '/api/high-scores', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/leaderboard'] });
    },
    onError: (error) => {
      console.warn('Failed to save high score to database:', error);
    }
  });

  // Mutation to save game score to database
  const saveGameScoreMutation = useMutation({
    mutationFn: async (data: {
      username: string;
      operation: string;
      score: number;
      correctAnswers: number;
      totalQuestions: number;
      accuracy: number;
    }) => {
      return apiRequest('POST', '/api/game-scores', data);
    },
    onError: (error) => {
      console.warn('Failed to save game score to database:', error);
    }
  });

  const highScores = hasUsername ? (databaseHighScores || defaultHighScores) : localHighScores;

  const updateHighScore = useCallback(async (operation: string, score: number, gameData?: {
    correctAnswers: number;
    totalQuestions: number;
  }) => {
    try {
      if (hasUsername && username) {
        // Save to database
        const accuracy = gameData ? Math.round((gameData.correctAnswers / gameData.totalQuestions) * 100) : 0;
        
        // Save game score
        if (gameData) {
          saveGameScoreMutation.mutate({
            username,
            operation,
            score,
            correctAnswers: gameData.correctAnswers,
            totalQuestions: gameData.totalQuestions,
            accuracy
          });
        }

        // Save high score
        saveHighScoreMutation.mutate({
          username,
          operation,
          score
        });
      } else {
        // Save to localStorage for anonymous users
        setLocalHighScores(prev => {
          const key = operation as keyof HighScores;
          if (key in prev && score > prev[key]) {
            return { ...prev, [key]: score };
          }
          return prev;
        });
      }
    } catch (error) {
      console.warn('Error updating high score:', error);
    }
  }, [hasUsername, username, saveHighScoreMutation, saveGameScoreMutation]);

  const getHighScore = useCallback((operation: string): number => {
    const key = operation as keyof HighScores;
    return highScores[key] || 0;
  }, [highScores]);

  const resetHighScores = useCallback(() => {
    if (!hasUsername) {
      setLocalHighScores(defaultHighScores);
      try {
        localStorage.removeItem('mathGameHighScores');
      } catch (error) {
        console.warn('Failed to reset high scores:', error);
      }
    }
  }, [hasUsername]);

  return {
    highScores,
    updateHighScore,
    getHighScore,
    resetHighScores
  };
}
