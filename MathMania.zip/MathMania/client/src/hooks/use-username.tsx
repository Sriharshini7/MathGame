import { useState, useEffect } from 'react';

export function useUsername() {
  const [username, setUsername] = useState<string>('');

  // Load username from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('mathGameUsername');
    if (saved) {
      setUsername(saved);
    }
  }, []);

  const updateUsername = (newUsername: string) => {
    setUsername(newUsername);
    localStorage.setItem('mathGameUsername', newUsername);
  };

  const clearUsername = () => {
    setUsername('');
    localStorage.removeItem('mathGameUsername');
  };

  return {
    username,
    updateUsername,
    clearUsername,
    hasUsername: username.length > 0
  };
}