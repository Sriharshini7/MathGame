import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useUsername } from "@/hooks/use-username";

interface UsernameInputProps {
  onComplete: () => void;
}

export default function UsernameInput({ onComplete }: UsernameInputProps) {
  const { updateUsername } = useUsername();
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim().length >= 2) {
      updateUsername(inputValue.trim());
      onComplete();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-blue-400 max-w-md w-full mx-4">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">👋</div>
          <h1 className="font-fredoka text-3xl kid-blue mb-2">Welcome to Math Adventure!</h1>
          <p className="text-lg text-gray-600">What should we call you?</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-lg font-medium text-gray-700 mb-2">
              Your Name:
            </label>
            <Input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Enter your name..."
              className="text-xl py-3 px-4 rounded-xl border-2 border-gray-300 focus:border-blue-500"
              maxLength={20}
              required
            />
          </div>

          <Button
            type="submit"
            disabled={inputValue.trim().length < 2}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold text-xl py-4 px-8 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:transform-none"
          >
            🚀 Start Playing!
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            Your scores will be saved so you can track your progress!
          </p>
        </div>
      </div>
    </div>
  );
}