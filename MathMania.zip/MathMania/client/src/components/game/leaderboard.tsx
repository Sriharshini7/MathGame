import { useQuery } from '@tanstack/react-query';
import { useUsername } from '@/hooks/use-username';

export default function Leaderboard() {
  const { username, hasUsername } = useUsername();

  const { data: leaderboards, isLoading } = useQuery({
    queryKey: ['/api/leaderboard'],
    enabled: hasUsername,
    select: (data: any[]) => data
  });

  if (!hasUsername || isLoading) {
    return null;
  }

  if (!leaderboards || leaderboards.every(lb => lb.scores.length === 0)) {
    return (
      <div className="bg-white rounded-3xl shadow-lg p-6 border-4 border-purple-400">
        <div className="text-center">
          <div className="text-4xl mb-2">🎯</div>
          <h3 className="font-fredoka text-2xl kid-purple mb-2">Global Leaderboard</h3>
          <p className="text-gray-600">Be the first to set a high score!</p>
        </div>
      </div>
    );
  }

  const operations = [
    { key: 'addition', symbol: '➕', color: 'blue' },
    { key: 'subtraction', symbol: '➖', color: 'red' },
    { key: 'multiplication', symbol: '✖️', color: 'green' },
    { key: 'division', symbol: '➗', color: 'purple' }
  ];

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6 border-4 border-purple-400">
      <div className="text-center mb-6">
        <div className="text-4xl mb-2">🏆</div>
        <h3 className="font-fredoka text-2xl kid-purple">Global Leaderboard</h3>
        <p className="text-sm text-gray-600">Top players across all operations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {operations.map(({ key, symbol, color }) => {
          const leaderboard = leaderboards.find(lb => lb.operation === key);
          const topScores = leaderboard?.scores?.slice(0, 3) || [];
          
          return (
            <div key={key} className={`bg-${color}-50 rounded-2xl p-4`}>
              <div className="text-center mb-3">
                <div className="text-2xl">{symbol}</div>
                <div className={`font-bold text-${color}-600 capitalize text-sm`}>{key}</div>
              </div>
              
              {topScores.length > 0 ? (
                <div className="space-y-2">
                  {topScores.map((score: any, index: number) => (
                    <div 
                      key={score.id} 
                      className={`flex justify-between items-center text-xs p-2 rounded-lg ${
                        score.username === username ? 'bg-white border-2 border-yellow-400' : 'bg-white/50'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="font-bold">{index + 1}.</span>
                        <span className={score.username === username ? 'font-bold text-yellow-700' : ''}>
                          {score.username === username ? '🌟 ' + score.username : score.username}
                        </span>
                      </div>
                      <span className={`font-bold text-${color}-600`}>{score.score}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-gray-500 text-xs">
                  No scores yet!
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}