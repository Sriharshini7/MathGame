interface OperationButtonProps {
  operation: string;
  symbol: string;
  title: string;
  description: string;
  example: string;
  colorClass: string;
  onClick: (operation: string) => void;
}

export default function OperationButton({
  operation,
  symbol,
  title,
  description,
  example,
  colorClass,
  onClick
}: OperationButtonProps) {
  return (
    <button
      onClick={() => onClick(operation)}
      className={`bg-gradient-to-r ${colorClass} text-white rounded-3xl p-8 shadow-xl transform hover:scale-105 transition-all duration-300 hover:shadow-2xl`}
    >
      <div className="text-6xl mb-4">{symbol}</div>
      <h3 className="font-fredoka text-2xl md:text-3xl mb-2">{title}</h3>
      <p className="text-lg opacity-90">{description}</p>
      <div className="mt-4 text-sm bg-white/20 rounded-full px-4 py-2 inline-block">
        Example: {example}
      </div>
    </button>
  );
}
