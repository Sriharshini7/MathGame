import { useHighScores } from "@/hooks/use-high-scores";

export default function HighScores() {
  const { highScores } = useHighScores();

  const operations = [
    { key: 'addition', symbol: '➕', color: 'kid-blue' },
    { key: 'subtraction', symbol: '➖', color: 'kid-red' },
    { key: 'multiplication', symbol: '✖️', color: 'kid-green' },
    { key: 'division', symbol: '➗', color: 'kid-purple' }
  ];

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6 border-4 border-yellow-400">
      <div className="flex items-center justify-center space-x-4">
        <span className="text-3xl">🏆</span>
        <div className="text-center">
          <h3 className="font-fredoka text-2xl kid-purple">High Scores</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            {operations.map(({ key, symbol, color }) => (
              <div key={key} className={`bg-${color}/10 rounded-xl p-3`}>
                <div className="text-lg">{symbol}</div>
                <div className={`font-bold ${color}`}>
                  {highScores[key as keyof typeof highScores]}
                </div>
              </div>
            ))}
          </div>
        </div>
        <span className="text-3xl">🏆</span>
      </div>
    </div>
  );
}
