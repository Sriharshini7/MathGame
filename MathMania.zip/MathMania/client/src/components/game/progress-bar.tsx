interface ProgressBarProps {
  progress: number;
  currentQuestion: number;
  totalQuestions: number;
}

export default function ProgressBar({ progress, currentQuestion, totalQuestions }: ProgressBarProps) {
  return (
    <>
      <div className="w-full bg-gray-200 rounded-full h-4">
        <div
          className="bg-gradient-to-r from-green-400 to-green-500 h-4 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="flex justify-between mt-2 text-sm text-gray-600">
        <span>🚀 Start</span>
        <span className="font-medium">
          {currentQuestion}/{totalQuestions}
        </span>
        <span>🏆 Finish</span>
      </div>
    </>
  );
}
