interface AnswerButtonProps {
  option: number;
  index: number;
  isSelected: boolean;
  isCorrect: boolean;
  isWrong: boolean;
  onClick: () => void;
  disabled: boolean;
}

export default function AnswerButton({
  option,
  index,
  isSelected,
  isCorrect,
  isWrong,
  onClick,
  disabled
}: AnswerButtonProps) {
  const getButtonColor = () => {
    if (isCorrect) return "from-green-500 to-green-600";
    if (isWrong) return "from-red-500 to-red-600";
    
    switch (index) {
      case 0: return "from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600";
      case 1: return "from-pink-400 to-pink-500 hover:from-pink-500 hover:to-pink-600";
      case 2: return "from-purple-400 to-purple-500 hover:from-purple-500 hover:to-purple-600";
      case 3: return "from-green-400 to-green-500 hover:from-green-500 hover:to-green-600";
      default: return "from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600";
    }
  };

  const getLetter = (index: number) => {
    return String.fromCharCode(65 + index); // A, B, C, D
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`bg-gradient-to-r ${getButtonColor()} text-white font-bold text-2xl py-6 px-8 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200 disabled:cursor-not-allowed ${
        isSelected ? 'ring-4 ring-white' : ''
      } ${disabled ? 'opacity-75' : ''}`}
    >
      {getLetter(index)}) {option}
    </button>
  );
}
