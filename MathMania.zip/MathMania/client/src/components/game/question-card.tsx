import AnswerButton from "./answer-button";

interface Question {
  id: number;
  operation: string;
  num1: number;
  num2: number;
  correctAnswer: number;
  options: number[];
  emoji: string;
}

interface QuestionCardProps {
  question: Question;
  selectedAnswer: number | null;
  showFeedback: boolean;
  isCorrect: boolean;
  onAnswerSelect: (answer: number) => void;
  disabled: boolean;
}

export default function QuestionCard({
  question,
  selectedAnswer,
  showFeedback,
  isCorrect,
  onAnswerSelect,
  disabled
}: QuestionCardProps) {
  const getOperationSymbol = (operation: string) => {
    switch (operation) {
      case 'addition': return '+';
      case 'subtraction': return '-';
      case 'multiplication': return '×';
      case 'division': return '÷';
      default: return '+';
    }
  };

  const questionText = `What is ${question.num1} ${getOperationSymbol(question.operation)} ${question.num2}?`;

  return (
    <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-blue-400">
      <div className="text-center mb-8">
        <div className="text-6xl mb-6">{question.emoji}</div>
        <h2 className="font-fredoka text-4xl md:text-5xl text-gray-800 mb-4">
          {questionText}
        </h2>
        <div className="text-lg text-gray-600">Choose the correct answer!</div>
      </div>

      {/* Answer Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {question.options.map((option, index) => (
          <AnswerButton
            key={option}
            option={option}
            index={index}
            isSelected={selectedAnswer === option}
            isCorrect={showFeedback && option === question.correctAnswer}
            isWrong={showFeedback && selectedAnswer === option && option !== question.correctAnswer}
            onClick={() => onAnswerSelect(option)}
            disabled={disabled}
          />
        ))}
      </div>

      {/* Timer/Encouragement */}
      <div className="text-center">
        <div className="inline-block bg-blue-50 rounded-full px-6 py-3">
          <span className="text-lg font-medium kid-blue">Take your time! 🕐</span>
        </div>
      </div>
    </div>
  );
}
