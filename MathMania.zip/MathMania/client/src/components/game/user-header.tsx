import { Button } from "@/components/ui/button";
import { useUsername } from "@/hooks/use-username";

export default function UserHeader() {
  const { username, clearUsername } = useUsername();

  const handleLogout = () => {
    clearUsername();
    window.location.reload();
  };

  return (
    <div className="flex justify-between items-center mb-6 bg-white rounded-2xl p-4 shadow-lg border-2 border-blue-200">
      <div className="flex items-center space-x-3">
        <div className="text-2xl">👋</div>
        <div>
          <h2 className="font-fredoka text-xl kid-blue">Hey, {username}!</h2>
          <p className="text-sm text-gray-600">Ready for some math fun?</p>
        </div>
      </div>
      
      <Button
        onClick={handleLogout}
        variant="outline"
        size="sm"
        className="text-gray-600 hover:text-gray-800"
      >
        Switch Player
      </Button>
    </div>
  );
}