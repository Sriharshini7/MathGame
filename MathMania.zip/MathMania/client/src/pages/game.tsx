import { useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useGameState } from "@/hooks/use-game-state";
import { playSound } from "@/lib/sound-effects";
import QuestionCard from "@/components/game/question-card";
import ProgressBar from "@/components/game/progress-bar";
import { Button } from "@/components/ui/button";

export default function Game() {
  const params = useParams();
  const operation = params.operation;
  const [, setLocation] = useLocation();
  const {
    questions,
    currentQuestionIndex,
    score,
    selectedAnswer,
    showFeedback,
    isCorrect,
    initializeGame,
    selectAnswer,
    nextQuestion,
    isGameComplete
  } = useGameState();

  useEffect(() => {
    if (operation) {
      initializeGame(operation);
    }
  }, [operation, initializeGame]);

  useEffect(() => {
    if (isGameComplete) {
      setTimeout(() => {
        setLocation('/results');
      }, 2000);
    }
  }, [isGameComplete, setLocation]);

  const handleAnswerSelect = (answer: number) => {
    selectAnswer(answer);
    
    // Play sound after a short delay to get the correct answer state
    setTimeout(() => {
      const currentQ = questions[currentQuestionIndex];
      const correct = answer === currentQ.correctAnswer;
      playSound(correct ? 'correct' : 'incorrect').catch(console.warn);
    }, 100);
    
    setTimeout(() => {
      nextQuestion();
    }, 2000);
  };

  const handleBackToHome = () => {
    setLocation('/');
  };

  if (!questions.length) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🎮</div>
          <h2 className="font-fredoka text-2xl text-gray-800">Loading your math adventure...</h2>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="space-y-6">
        {/* Game Header with Progress */}
        <div className="bg-white rounded-3xl shadow-lg p-6 border-4 border-green-400">
          <div className="flex justify-between items-center mb-4">
            <Button
              onClick={handleBackToHome}
              variant="outline"
              className="px-6 py-3 rounded-xl font-bold"
            >
              ← Back
            </Button>
            <div className="text-center">
              <div className="font-fredoka text-2xl kid-purple capitalize">{operation}</div>
              <div className="text-sm text-gray-600">
                Question {currentQuestionIndex + 1} of {questions.length}
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl">🎯</div>
              <div className="font-bold kid-blue text-xl">{score}</div>
            </div>
          </div>
          
          <ProgressBar 
            progress={progressPercentage}
            currentQuestion={currentQuestionIndex + 1}
            totalQuestions={questions.length}
          />
        </div>

        {/* Question Card */}
        <QuestionCard
          question={currentQuestion}
          selectedAnswer={selectedAnswer}
          showFeedback={showFeedback}
          isCorrect={isCorrect}
          onAnswerSelect={handleAnswerSelect}
          disabled={showFeedback}
        />

        {/* Feedback Section */}
        {showFeedback && (
          <div className={`rounded-3xl p-6 text-center border-4 ${
            isCorrect 
              ? 'bg-green-100 border-green-400' 
              : 'bg-red-100 border-red-400'
          }`}>
            <div className="text-6xl mb-4">{isCorrect ? '🎉' : '💪'}</div>
            <h3 className={`font-fredoka text-3xl mb-2 ${
              isCorrect ? 'text-green-700' : 'text-red-700'
            }`}>
              {isCorrect ? 'Awesome! That\'s Correct!' : 'Good Try! Let\'s Learn!'}
            </h3>
            <p className={`text-lg ${
              isCorrect ? 'text-green-600' : 'text-red-600'
            }`}>
              {isCorrect 
                ? 'You earned 10 points! Keep going!' 
                : `The correct answer was ${currentQuestion.correctAnswer}. You'll get it next time!`
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
