import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useGameState } from "@/hooks/use-game-state";
import { useHighScores } from "@/hooks/use-high-scores";
import { playSound } from "@/lib/sound-effects";
import { Button } from "@/components/ui/button";

interface GameResults {
  score: number;
  operation: string;
  correctAnswers: number;
  totalQuestions: number;
}

export default function Results() {
  const [, setLocation] = useLocation();
  const { score: stateScore, operation: stateOperation, correctAnswers: stateCorrectAnswers, totalQuestions: stateTotalQuestions, resetGame } = useGameState();
  const { getHighScore, updateHighScore } = useHighScores();
  const [gameResults, setGameResults] = useState<GameResults | null>(null);

  // Always initialize hooks first - moved all hooks before any conditional returns
  const [hasPlayedCelebration, setHasPlayedCelebration] = useState(false);

  // Load game results from sessionStorage if available
  useEffect(() => {
    try {
      const savedResults = sessionStorage.getItem('mathGameResults');
      if (savedResults) {
        const parsed = JSON.parse(savedResults);
        setGameResults(parsed);
        console.log('Loaded results from sessionStorage:', parsed);
      } else {
        console.log('No saved results, using state:', { 
          score: stateScore, 
          operation: stateOperation, 
          correctAnswers: stateCorrectAnswers, 
          totalQuestions: stateTotalQuestions 
        });
        setGameResults({
          score: stateScore,
          operation: stateOperation,
          correctAnswers: stateCorrectAnswers,
          totalQuestions: stateTotalQuestions
        });
      }
    } catch (error) {
      console.error('Error loading game results:', error);
      setGameResults({
        score: stateScore,
        operation: stateOperation,
        correctAnswers: stateCorrectAnswers,
        totalQuestions: stateTotalQuestions
      });
    }
  }, [stateScore, stateOperation, stateCorrectAnswers, stateTotalQuestions]);

  // Calculate derived values with safe defaults
  const score = gameResults?.score || 0;
  const operation = gameResults?.operation || 'addition';
  const correctAnswers = gameResults?.correctAnswers || 0;
  const totalQuestions = gameResults?.totalQuestions || 1;

  const accuracy = Math.round((correctAnswers / totalQuestions) * 100);
  const previousHighScore = getHighScore(operation);
  const isNewHighScore = score > previousHighScore;
  const isPerfectScore = correctAnswers === totalQuestions;
  const isGoodScore = accuracy >= 80;

  useEffect(() => {
    if (gameResults && operation && score > 0 && !hasPlayedCelebration) {
      updateHighScore(operation, score, { correctAnswers, totalQuestions });
      playSound('celebration').catch(console.warn);
      setHasPlayedCelebration(true);
    }
  }, [gameResults, operation, score, correctAnswers, totalQuestions, updateHighScore, hasPlayedCelebration]);

  // Early return after all hooks are defined
  if (!gameResults) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">⏳</div>
          <h2 className="font-fredoka text-2xl text-gray-800">Loading your results...</h2>
        </div>
      </div>
    );
  }

  const handlePlayAgain = () => {
    sessionStorage.removeItem('mathGameResults');
    resetGame();
    setLocation(`/game/${operation}`);
  };

  const handleReturnHome = () => {
    sessionStorage.removeItem('mathGameResults');
    resetGame();
    setLocation('/');
  };

  const getResultMessage = () => {
    if (isPerfectScore) return "Perfect! Amazing Work!";
    if (isGoodScore) return "Excellent Job!";
    if (accuracy >= 60) return "Good Effort!";
    return "Keep Practicing!";
  };

  const getResultEmoji = () => {
    if (isPerfectScore) return "🏆";
    if (isGoodScore) return "🌟";
    if (accuracy >= 60) return "👍";
    return "💪";
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="space-y-8">
        {/* Celebration Header */}
        <div className="text-center">
          <div className="text-8xl mb-4 animate-bounce-gentle">🏆</div>
          <h1 className="font-fredoka text-4xl md:text-6xl kid-purple mb-4">
            Game Complete!
          </h1>
        </div>

        {/* Score Card */}
        <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-yellow-400 relative overflow-hidden">
          {/* Confetti Background */}
          <div className="absolute inset-0 opacity-20">
            <div className="text-6xl absolute top-4 left-4 animate-pulse">🎊</div>
            <div className="text-6xl absolute top-4 right-4 animate-pulse">✨</div>
            <div className="text-6xl absolute bottom-4 left-1/4 animate-pulse">🌟</div>
            <div className="text-6xl absolute bottom-4 right-1/4 animate-pulse">🎉</div>
          </div>
          
          <div className="relative z-10 text-center">
            <div className="mb-6">
              <div className="text-6xl mb-4">{getResultEmoji()}</div>
              <h2 className="font-fredoka text-3xl md:text-4xl text-gray-800 mb-2">
                {getResultMessage()}
              </h2>
              <p className="text-lg text-gray-600">
                You completed the <span className="capitalize font-semibold">{operation}</span> challenge!
              </p>
            </div>

            {/* Score Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-blue-50 rounded-2xl p-6">
                <div className="text-4xl mb-2">📊</div>
                <div className="font-fredoka text-2xl kid-blue">{score}</div>
                <div className="text-sm text-gray-600">Final Score</div>
              </div>
              <div className="bg-green-50 rounded-2xl p-6">
                <div className="text-4xl mb-2">✅</div>
                <div className="font-fredoka text-2xl kid-green">{correctAnswers}</div>
                <div className="text-sm text-gray-600">Correct Answers</div>
              </div>
              <div className="bg-purple-50 rounded-2xl p-6">
                <div className="text-4xl mb-2">📈</div>
                <div className="font-fredoka text-2xl kid-purple">{accuracy}%</div>
                <div className="text-sm text-gray-600">Accuracy</div>
              </div>
            </div>

            {/* New High Score Banner */}
            {isNewHighScore && (
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white rounded-2xl p-6 mb-6 animate-celebration">
                <div className="text-4xl mb-2">🎯</div>
                <h3 className="font-fredoka text-2xl mb-2">NEW HIGH SCORE!</h3>
                <p className="text-lg">You beat your previous best score!</p>
              </div>
            )}

            {/* Achievement Badges */}
            <div className="flex justify-center space-x-4 mb-8">
              {isPerfectScore && (
                <div className="bg-green-50 rounded-full p-4">
                  <div className="text-3xl">🎯</div>
                  <div className="text-xs kid-green font-bold mt-1">Perfect!</div>
                </div>
              )}
              {isGoodScore && (
                <div className="bg-blue-50 rounded-full p-4">
                  <div className="text-3xl">⚡</div>
                  <div className="text-xs kid-blue font-bold mt-1">Excellent!</div>
                </div>
              )}
              {isNewHighScore && (
                <div className="bg-purple-50 rounded-full p-4">
                  <div className="text-3xl">📈</div>
                  <div className="text-xs kid-purple font-bold mt-1">New Best!</div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            onClick={handlePlayAgain}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold text-xl py-6 px-8 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            🔄 Play Again
          </Button>
          <Button
            onClick={handleReturnHome}
            className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold text-xl py-6 px-8 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            🏠 Choose New Game
          </Button>
        </div>

        {/* Motivational Message */}
        <div className="text-center bg-gradient-to-r from-pink-100 to-purple-100 rounded-3xl p-6">
          <div className="text-4xl mb-4">🌈 ⭐ 🎈</div>
          <h3 className="font-fredoka text-2xl text-gray-800 mb-2">You're a Math Superstar!</h3>
          <p className="text-lg text-gray-600">Keep practicing to become even better at math!</p>
        </div>
      </div>
    </div>
  );
}
