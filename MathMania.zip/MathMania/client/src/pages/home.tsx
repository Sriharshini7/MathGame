import { useLocation } from "wouter";
import OperationButton from "@/components/game/operation-button";
import HighScores from "@/components/game/high-scores";
import Leaderboard from "@/components/game/leaderboard";
import UserHeader from "@/components/game/user-header";

export default function Home() {
  const [, setLocation] = useLocation();

  const handleOperationSelect = (operation: string) => {
    setLocation(`/game/${operation}`);
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      {/* User Header */}
      <UserHeader />

      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="font-fredoka text-4xl md:text-6xl kid-blue mb-2">
          🧮 Math Adventure! 🎯
        </h1>
        <p className="text-lg md:text-xl text-gray-600 font-medium">
          Let's learn math the fun way!
        </p>
      </header>

      <div className="space-y-8">
        {/* High Score Display and Leaderboard */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <HighScores />
          <Leaderboard />
        </div>

        {/* Operation Selection */}
        <div className="text-center mb-8">
          <h2 className="font-fredoka text-3xl md:text-4xl text-gray-800 mb-6">
            Choose Your Math Adventure! 🚀
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <OperationButton
              operation="addition"
              symbol="➕"
              title="Addition"
              description="Add numbers together!"
              example="5 + 3 = 8"
              colorClass="from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
              onClick={handleOperationSelect}
            />
            
            <OperationButton
              operation="subtraction"
              symbol="➖"
              title="Subtraction"
              description="Take numbers away!"
              example="8 - 3 = 5"
              colorClass="from-red-500 to-red-600 hover:from-red-600 hover:to-red-700"
              onClick={handleOperationSelect}
            />
            
            <OperationButton
              operation="multiplication"
              symbol="✖️"
              title="Multiplication"
              description="Groups of numbers!"
              example="4 × 3 = 12"
              colorClass="from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
              onClick={handleOperationSelect}
            />
            
            <OperationButton
              operation="division"
              symbol="➗"
              title="Division"
              description="Share equally!"
              example="12 ÷ 4 = 3"
              colorClass="from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
              onClick={handleOperationSelect}
            />
          </div>
        </div>

        {/* Fun Encouragement Section */}
        <div className="text-center bg-gradient-to-r from-yellow-100 to-pink-100 rounded-3xl p-6">
          <div className="text-4xl mb-4">🌟 ✨ 🎊</div>
          <h3 className="font-fredoka text-2xl text-gray-800 mb-2">Ready to Become a Math Hero?</h3>
          <p className="text-lg text-gray-600">Pick an operation above and let's start the adventure!</p>
        </div>
      </div>
    </div>
  );
}
