# Math Adventure Game - Replit Setup Guide

## Overview

This is a full-stack math learning game for kids, built with React frontend and Express backend. The application features interactive math games covering addition, subtraction, multiplication, and division with a kid-friendly interface, scoring system, and high score tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: React hooks with custom state management
- **UI Library**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom kid-friendly color scheme
- **Build Tool**: Vite with custom configuration for client-side building

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Module System**: ES Modules
- **Development**: TSX for TypeScript execution
- **API Structure**: RESTful endpoints (currently minimal setup)
- **Storage Interface**: Abstracted storage layer with in-memory implementation

### Key Components

#### Game Logic
- **Question Generation**: Dynamic math problem creation for each operation type
- **Scoring System**: 10 points per correct answer with accuracy tracking
- **Difficulty Scaling**: Age-appropriate number ranges for different operations
- **Sound Effects**: Web Audio API implementation for interactive feedback

#### State Management
- **Game State Hook**: Manages current question, score, progress, and game completion
- **High Scores Hook**: Persists user achievements in localStorage with fallback handling
- **Mobile Detection**: Responsive design hooks for mobile optimization

#### UI Components
- **Kid-Friendly Design**: Bright colors, large buttons, emoji feedback
- **Accessibility**: Screen reader support and keyboard navigation
- **Responsive Layout**: Mobile-first design with tablet and desktop scaling

### Data Flow

1. **Game Initialization**: User selects operation → Game state initialized with 10 questions
2. **Question Flow**: Display question → User selects answer → Show feedback → Progress to next
3. **Score Tracking**: Real-time score updates → High score comparison → localStorage persistence
4. **Results Display**: Final score → Achievement celebration → High score update

### External Dependencies

#### Core Dependencies
- **React Ecosystem**: React, React DOM, React Query for state management
- **UI Framework**: Radix UI primitives for accessible components
- **Routing**: Wouter for lightweight client-side routing
- **Database**: Drizzle ORM with PostgreSQL dialect (configured but not implemented)
- **Validation**: Zod for schema validation and type safety

#### Development Tools
- **Build System**: Vite with React plugin and development error overlay
- **TypeScript**: Full type coverage with strict configuration
- **Styling**: Tailwind CSS with PostCSS for processing
- **Code Quality**: ESBuild for fast bundling

#### Database Schema
- **Users Table**: Basic user structure with username/password (prepared for future authentication)
- **Schema Location**: `shared/schema.ts` for cross-platform type sharing
- **ORM**: Drizzle with Zod integration for runtime validation

### Deployment Strategy

#### Build Process
1. **Client Build**: Vite builds React app to `dist/public`
2. **Server Build**: ESBuild bundles Express server to `dist/index.js`
3. **Asset Handling**: Static file serving with Vite middleware in development

#### Environment Configuration
- **Development**: Hot reload with Vite middleware and TSX execution
- **Production**: Compiled JavaScript with static file serving
- **Database**: Environment variable configuration for PostgreSQL connection

#### Hosting Considerations
- **Static Assets**: Optimized for CDN deployment
- **API Routes**: Express server handles `/api/*` endpoints
- **Session Management**: Prepared for PostgreSQL session storage
- **Error Handling**: Comprehensive error boundaries and API error responses

#### Performance Features
- **Code Splitting**: Automatic route-based splitting with Vite
- **Asset Optimization**: Tailwind CSS purging and image optimization
- **Caching Strategy**: Query client configuration for API response caching
- **Mobile Performance**: Lightweight bundle with responsive images

## Recent Changes (July 2025)

### Bug Fixes (July 11, 2025)
- **React Hooks Issue**: Fixed "more hooks than previous render" error in Results component
- **API Request Bug**: Corrected parameter order in apiRequest function calls (method, url, data)
- **Error Handling**: Added comprehensive error boundaries and improved mutation error handling
- **Sound Effects**: Fixed promise handling and timeout cleanup in Web Audio API
- **Database Connectivity**: Enhanced error handling for database operations with proper fallbacks

### Previous Updates (January 2025)
- **Database Integration**: Migrated from in-memory storage to PostgreSQL with Drizzle ORM
- **User System**: Added username input and user profile management
- **Global Leaderboards**: Implemented database-backed leaderboards with real-time updates
- **Game Score Tracking**: Added persistent storage for all game sessions and achievements
- **Hybrid Storage**: Maintained localStorage fallback for anonymous users
- **API Endpoints**: Created RESTful API for scores, high scores, and leaderboards

## Technical Notes

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Strategy**: Database storage for registered users, localStorage for anonymous play
- **Sound Effects**: Web Audio API with graceful fallback for unsupported browsers
- **Score Persistence**: All game data stored in database with real-time leaderboard updates
- **UI System**: Fully accessible with ARIA labels and keyboard navigation
- **Performance**: Optimized with TanStack Query for efficient data fetching and caching
- **User Experience**: Seamless transition between anonymous and registered gameplay