import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameScoreSchema, insertHighScoreSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Game scores API
  app.post("/api/game-scores", async (req, res) => {
    try {
      const validatedData = insertGameScoreSchema.parse(req.body);
      const gameScore = await storage.saveGameScore(validatedData);
      res.json(gameScore);
    } catch (error) {
      console.error("Error saving game score:", error);
      res.status(400).json({ error: "Invalid game score data" });
    }
  });

  app.get("/api/game-scores/:username", async (req, res) => {
    try {
      const { username } = req.params;
      const gameScores = await storage.getGameScores(username);
      res.json(gameScores);
    } catch (error) {
      console.error("Error fetching game scores:", error);
      res.status(500).json({ error: "Failed to fetch game scores" });
    }
  });

  // High scores API
  app.post("/api/high-scores", async (req, res) => {
    try {
      const validatedData = insertHighScoreSchema.parse(req.body);
      const highScore = await storage.saveHighScore(validatedData);
      res.json(highScore);
    } catch (error) {
      console.error("Error saving high score:", error);
      res.status(400).json({ error: "Invalid high score data" });
    }
  });

  app.get("/api/high-scores/:username/:operation", async (req, res) => {
    try {
      const { username, operation } = req.params;
      const highScore = await storage.getHighScore(username, operation);
      res.json(highScore || { score: 0 });
    } catch (error) {
      console.error("Error fetching high score:", error);
      res.status(500).json({ error: "Failed to fetch high score" });
    }
  });

  // Leaderboard API
  app.get("/api/leaderboard/:operation", async (req, res) => {
    try {
      const { operation } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const leaderboard = await storage.getLeaderboard(operation, limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  // Global leaderboard (all operations)
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const operations = ['addition', 'subtraction', 'multiplication', 'division'];
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      
      const leaderboards = await Promise.all(
        operations.map(async (operation) => ({
          operation,
          scores: await storage.getLeaderboard(operation, limit)
        }))
      );
      
      res.json(leaderboards);
    } catch (error) {
      console.error("Error fetching global leaderboard:", error);
      res.status(500).json({ error: "Failed to fetch global leaderboard" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
