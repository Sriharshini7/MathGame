import { 
  users, 
  gameScores, 
  highScores,
  type User, 
  type InsertUser,
  type GameScore,
  type InsertGameScore,
  type HighScore,
  type InsertHighScore
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  saveGameScore(gameScore: InsertGameScore): Promise<GameScore>;
  getGameScores(username: string): Promise<GameScore[]>;
  getHighScore(username: string, operation: string): Promise<HighScore | undefined>;
  saveHighScore(highScore: InsertHighScore): Promise<HighScore>;
  getLeaderboard(operation: string, limit?: number): Promise<HighScore[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async saveGameScore(gameScore: InsertGameScore): Promise<GameScore> {
    const [score] = await db
      .insert(gameScores)
      .values(gameScore)
      .returning();
    return score;
  }

  async getGameScores(username: string): Promise<GameScore[]> {
    return await db
      .select()
      .from(gameScores)
      .where(eq(gameScores.username, username))
      .orderBy(desc(gameScores.playedAt));
  }

  async getHighScore(username: string, operation: string): Promise<HighScore | undefined> {
    const [highScore] = await db
      .select()
      .from(highScores)
      .where(and(eq(highScores.username, username), eq(highScores.operation, operation)))
      .orderBy(desc(highScores.score))
      .limit(1);
    return highScore || undefined;
  }

  async saveHighScore(highScore: InsertHighScore): Promise<HighScore> {
    // First check if user already has a high score for this operation
    const existing = await this.getHighScore(highScore.username, highScore.operation);
    
    if (existing && existing.score < highScore.score) {
      // Update existing high score
      const [updated] = await db
        .update(highScores)
        .set({ score: highScore.score, achievedAt: new Date() })
        .where(eq(highScores.id, existing.id))
        .returning();
      return updated;
    } else if (!existing) {
      // Insert new high score
      const [newHighScore] = await db
        .insert(highScores)
        .values(highScore)
        .returning();
      return newHighScore;
    }
    
    // Return existing if no update needed
    return existing;
  }

  async getLeaderboard(operation: string, limit: number = 10): Promise<HighScore[]> {
    return await db
      .select()
      .from(highScores)
      .where(eq(highScores.operation, operation))
      .orderBy(desc(highScores.score))
      .limit(limit);
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private gameScoresData: Map<string, GameScore[]>;
  private highScoresData: Map<string, HighScore>;
  currentId: number;
  currentScoreId: number;

  constructor() {
    this.users = new Map();
    this.gameScoresData = new Map();
    this.highScoresData = new Map();
    this.currentId = 1;
    this.currentScoreId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async saveGameScore(gameScore: InsertGameScore): Promise<GameScore> {
    const id = this.currentScoreId++;
    const score: GameScore = { 
      ...gameScore, 
      id, 
      playedAt: new Date() 
    };
    
    const userScores = this.gameScoresData.get(gameScore.username) || [];
    userScores.push(score);
    this.gameScoresData.set(gameScore.username, userScores);
    
    return score;
  }

  async getGameScores(username: string): Promise<GameScore[]> {
    return this.gameScoresData.get(username) || [];
  }

  async getHighScore(username: string, operation: string): Promise<HighScore | undefined> {
    const key = `${username}-${operation}`;
    return this.highScoresData.get(key);
  }

  async saveHighScore(highScore: InsertHighScore): Promise<HighScore> {
    const key = `${highScore.username}-${highScore.operation}`;
    const existing = this.highScoresData.get(key);
    
    if (!existing || existing.score < highScore.score) {
      const newHighScore: HighScore = {
        ...highScore,
        id: this.currentScoreId++,
        achievedAt: new Date()
      };
      this.highScoresData.set(key, newHighScore);
      return newHighScore;
    }
    
    return existing;
  }

  async getLeaderboard(operation: string, limit: number = 10): Promise<HighScore[]> {
    const allHighScores = Array.from(this.highScoresData.values())
      .filter(score => score.operation === operation)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
    
    return allHighScores;
  }
}

export const storage = new DatabaseStorage();
