# 🧮 Math Adventure Game

A fun and colorful math learning game for children built with React, TypeScript, and Tailwind CSS. Features interactive gameplay, sound effects, and a global leaderboard system.

## 🌟 Features

- **Four Math Operations**: Addition, Subtraction, Multiplication, and Division
- **Interactive Gameplay**: 10 multiple-choice questions per game session
- **Kid-Friendly Design**: Bright colors, large buttons, emojis, and animations
- **Sound Effects**: Audio feedback for correct/incorrect answers using Web Audio API
- **Progress Tracking**: Real-time progress bar and score display
- **High Score System**: Personal high scores and global leaderboards
- **Database Storage**: PostgreSQL database for persistent score tracking
- **Responsive Design**: Optimized for mobile, tablet, and desktop
- **User Profiles**: Simple username system for score tracking

## 🎮 How to Play

1. Enter your name to start playing
2. Choose a math operation from the home screen
3. Answer 10 multiple-choice questions
4. Get immediate feedback on each answer
5. View your final score and achievements
6. Compare your scores on the global leaderboard

## 🚀 Getting Started

### Prerequisites

- Node.js 20 or higher
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd math-adventure-game
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
# Create .env file with your database connection
DATABASE_URL=your_postgresql_connection_string
```

4. Push database schema:
```bash
npm run db:push
```

5. Start the development server:
```bash
npm run dev
```

6. Open your browser and visit `http://localhost:5000`

## 🏗️ Tech Stack

### Frontend
- **React 18** with TypeScript
- **Wouter** for routing
- **Tailwind CSS** for styling
- **Shadcn/ui** components
- **TanStack Query** for data fetching
- **Framer Motion** for animations

### Backend
- **Express.js** with TypeScript
- **Drizzle ORM** for database operations
- **PostgreSQL** for data storage
- **Zod** for validation

### Features
- **Web Audio API** for sound effects
- **LocalStorage** fallback for anonymous users
- **Responsive design** with mobile-first approach
- **Real-time leaderboards** with database persistence

## 📱 Responsive Design

The game is optimized for all screen sizes:
- **Mobile**: Touch-friendly buttons and simplified layout
- **Tablet**: Grid layout for operation selection
- **Desktop**: Full leaderboard and enhanced visual effects

## 🎨 Design Philosophy

- **Kid-Friendly**: Large buttons, bright colors, and encouraging feedback
- **Accessible**: ARIA labels and keyboard navigation support
- **Performance**: Optimized bundle size and fast loading times
- **Progressive Enhancement**: Works offline with localStorage fallback

## 🔧 Development Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run db:push      # Push database schema changes
npm run type-check   # Run TypeScript type checking
```

## 📊 Database Schema

The application uses three main tables:
- **users**: Basic user information
- **game_scores**: Individual game session results
- **high_scores**: Best scores per operation per user

## 🎵 Sound Effects

Built-in sound effects using Web Audio API:
- Success sounds for correct answers
- Gentle feedback for incorrect answers
- Celebration fanfare for game completion
- Click sounds for UI interactions

## 🏆 Scoring System

- **10 points** per correct answer
- **Accuracy percentage** calculation
- **High score tracking** per operation
- **Global leaderboards** with top players

## 🌟 Educational Benefits

- **Number Recognition**: Visual number patterns
- **Mental Math**: Quick calculation practice
- **Problem Solving**: Multiple choice strategy
- **Progress Tracking**: Motivation through achievement
- **Healthy Competition**: Global leaderboards

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

Built with ❤️ for young mathematicians everywhere! 🎯