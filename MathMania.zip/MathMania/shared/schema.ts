import { pgTable, text, serial, integer, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gameScores = pgTable("game_scores", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull(),
  operation: varchar("operation", { length: 20 }).notNull(),
  score: integer("score").notNull(),
  correctAnswers: integer("correct_answers").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  accuracy: integer("accuracy").notNull(),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});

export const highScores = pgTable("high_scores", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull(),
  operation: varchar("operation", { length: 20 }).notNull(),
  score: integer("score").notNull(),
  achievedAt: timestamp("achieved_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  gameScores: many(gameScores),
  highScores: many(highScores),
}));

export const gameScoresRelations = relations(gameScores, ({ one }) => ({
  user: one(users, {
    fields: [gameScores.username],
    references: [users.username],
  }),
}));

export const highScoresRelations = relations(highScores, ({ one }) => ({
  user: one(users, {
    fields: [highScores.username],
    references: [users.username],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGameScoreSchema = createInsertSchema(gameScores).pick({
  username: true,
  operation: true,
  score: true,
  correctAnswers: true,
  totalQuestions: true,
  accuracy: true,
});

export const insertHighScoreSchema = createInsertSchema(highScores).pick({
  username: true,
  operation: true,
  score: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type GameScore = typeof gameScores.$inferSelect;
export type InsertGameScore = z.infer<typeof insertGameScoreSchema>;
export type HighScore = typeof highScores.$inferSelect;
export type InsertHighScore = z.infer<typeof insertHighScoreSchema>;
